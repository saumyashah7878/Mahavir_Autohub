/* AutoHub – Car Showroom Management (frontend)
   Data is stored in the browser (localStorage) and seeded from the SQL project.
   To connect a real backend, replace load()/save() with fetch() calls to your API. */

/* ---------- Seed data (same as the SQL INSERTs) ---------- */
const rows = (keys, list) => list.map(r => Object.fromEntries(keys.map((k, i) => [k, r[i]])));
const SEED = {
  showroom: rows(['showroom_id','showroom_name','address','city','state','pincode','phone','email','established_date','rc_book','status'], [
    [1,'Prime Motors','MG Road','Ahmedabad','Gujarat','380001','9876500001','prime@gmail.com','2018-01-15','RC101','Active'],
    [2,'City Cars','SG Highway','Ahmedabad','Gujarat','380054','9876500002','city@gmail.com','2019-03-20','RC102','Active'],
    [3,'Royal Automobiles','Ring Road','Surat','Gujarat','395002','9876500003','royal@gmail.com','2020-06-10','RC103','Active'],
    [4,'Speed Motors','Alkapuri','Vadodara','Gujarat','390007','9876500004','speed@gmail.com','2017-09-12','RC104','Active'],
    [5,'Dream Cars','Kalawad Road','Rajkot','Gujarat','360001','9876500005','dream@gmail.com','2021-02-25','RC105','Active']]),
  employee: rows(['employee_id','showroom_id','first_name','last_name','designation','salary','phone','email','hire_date','status'], [
    [1,1,'Amit','Patel','Manager',55000,'9811100001','amit@gmail.com','2020-01-10','Active'],
    [2,2,'Riya','Shah','Sales Executive',30000,'9811100002','riya@gmail.com','2021-04-15','Active'],
    [3,3,'Rahul','Mehta','Accountant',35000,'9811100003','rahul@gmail.com','2022-02-20','Active'],
    [4,4,'Neha','Joshi','Sales Executive',32000,'9811100004','neha@gmail.com','2023-06-01','Active'],
    [5,5,'Karan','Desai','Service Advisor',28000,'9811100005','karan@gmail.com','2022-11-12','Active']]),
  supplier: rows(['supplier_id','supplier_name','contact_person','phone','email','address','gst_no','status'], [
    [1,'Auto Supply Ltd','Vijay Shah','9822200001','auto@gmail.com','Ahmedabad','GSTSUP001','Active'],
    [2,'Motor India','Rakesh Patel','9822200002','motor@gmail.com','Surat','GSTSUP002','Active'],
    [3,'Car World Ltd','Sanjay Mehta','9822200003','carworld@gmail.com','Vadodara','GSTSUP003','Active'],
    [4,'Speed Auto Ltd','Amit Joshi','9822200004','speedauto@gmail.com','Rajkot','GSTSUP004','Active'],
    [5,'National Motors','Manish Desai','9822200005','national@gmail.com','Gandhinagar','GSTSUP005','Active']]),
  car: rows(['car_id','showroom_id','supplier_id','brand','model','variant','fuel_type','price','status'], [
    [1,1,1,'Hyundai','Creta','SX','Petrol',1200000,'Sold'],
    [2,2,2,'Maruti Suzuki','Swift','VXI','Petrol',750000,'Sold'],
    [3,3,3,'Tata','Nexon','XZ+','Diesel',1100000,'Sold'],
    [4,4,4,'Mahindra','Thar','LX','Diesel',1500000,'Sold'],
    [5,5,5,'Honda','City','ZX','Petrol',1400000,'Sold'],
    [6,1,1,'Toyota','Innova','ZX','Diesel',2500000,'Available']]), // extra in-stock car so you can try a new sale
  customer: rows(['customer_id','first_name','last_name','phone','email','address','aadhaar_no','pan_no'], [
    [1,'Raj','Sharma','9833300001','raj@gmail.com','Ahmedabad','123456789001','ABCDE1234F'],
    [2,'Priya','Verma','9833300002','priya@gmail.com','Surat','123456789002','BCDEF2345G'],
    [3,'Arjun','Singh','9833300003','arjun@gmail.com','Vadodara','123456789003','CDEFG3456H'],
    [4,'Sneha','Rao','9833300004','sneha@gmail.com','Rajkot','123456789004','DEFGH4567J'],
    [5,'Vikram','Joshi','9833300005','vikram@gmail.com','Gandhinagar','123456789005','EFGHI5678K']]),
  sales: rows(['sale_id','customer_id','employee_id','car_id','sale_date','discount','tax','total_amount','payment_status'], [
    [1,1,1,1,'2026-01-10',20000,180000,1360000,'Paid'],
    [2,2,2,2,'2026-02-15',10000,100000,840000,'Paid'],
    [3,3,3,3,'2026-03-05',15000,150000,1235000,'Paid'],
    [4,4,4,4,'2026-04-12',25000,200000,1675000,'Pending'],
    [5,5,5,5,'2026-05-20',30000,180000,1550000,'Pending']]),
  service: rows(['jobcard_no','customer_id','car_id','service_date','service_type','service_cost','next_service_date','status'], [
    [1,1,1,'2026-02-10','Oil Change',3000,'2026-08-10','Completed'],
    [2,2,2,'2026-03-15','General Service',2500,'2026-09-15','Completed'],
    [3,3,3,'2026-04-05','Engine Check',5000,'2026-10-05','Pending'],
    [4,4,4,'2026-05-12','Brake Service',4500,'2026-11-12','Completed'],
    [5,5,5,'2026-06-20','AC Service',3500,'2026-12-20','Pending']]),
  payment: rows(['payment_id','sale_id','payment_date','amount','payment_mode','transaction_no','status'], [
    [1,1,'2026-01-10',1360000,'UPI','TXN1001','Completed'],
    [2,2,'2026-02-15',840000,'Card','TXN1002','Completed'],
    [3,3,'2026-03-05',1235000,'Bank Transfer','TXN1003','Completed'],
    [4,4,'2026-04-12',500000,'UPI','TXN1004','Completed'],
    [5,5,'2026-05-20',700000,'Cash','TXN1005','Completed']])
};

/* ---------- Schema: drives tables, forms and validation ---------- */
const f = (k, label, type = 'text', req = false, opts = null, def = '') => ({ k, label, type, req, opts, def });
const T = {
  showroom: { title: 'Showrooms', icon: '🏢', pk: 'showroom_id', list: ['showroom_id','showroom_name','city','phone','email','status'], fields: [
    f('showroom_name','Showroom Name','text',true), f('address','Address'), f('city','City'), f('state','State'),
    f('pincode','Pincode'), f('phone','Phone','tel'), f('email','Email','email'), f('established_date','Established','date'),
    f('rc_book','RC Book No.'), f('status','Status','select',false,['Active','Inactive'],'Active')] },
  employee: { title: 'Employees', icon: '👤', pk: 'employee_id', list: ['employee_id','first_name','last_name','showroom_id','designation','salary','phone','status'], fields: [
    f('showroom_id','Showroom','fk',true,'showroom'), f('first_name','First Name','text',true), f('last_name','Last Name'),
    f('designation','Designation','select',false,['Manager','Sales Executive','Accountant','Service Advisor','Mechanic']),
    f('salary','Salary (₹)','number'), f('phone','Phone','tel'), f('email','Email','email'), f('hire_date','Hire Date','date'),
    f('status','Status','select',false,['Active','Inactive'],'Active')] },
  supplier: { title: 'Suppliers', icon: '🚚', pk: 'supplier_id', list: ['supplier_id','supplier_name','contact_person','phone','address','gst_no','status'], fields: [
    f('supplier_name','Supplier Name','text',true), f('contact_person','Contact Person'), f('phone','Phone','tel'),
    f('email','Email','email'), f('address','Address'), f('gst_no','GST No.'),
    f('status','Status','select',false,['Active','Inactive'],'Active')] },
  car: { title: 'Cars', icon: '🚘', pk: 'car_id', list: ['car_id','brand','model','variant','fuel_type','price','showroom_id','supplier_id','status'], fields: [
    f('showroom_id','Showroom','fk',true,'showroom'), f('supplier_id','Supplier','fk',true,'supplier'),
    f('brand','Brand','text',true), f('model','Model','text',true), f('variant','Variant'),
    f('fuel_type','Fuel Type','select',false,['Petrol','Diesel','CNG','Electric','Hybrid']),
    f('price','Price (₹)','number',true), f('status','Status','select',false,['Available','Sold','Reserved'],'Available')] },
  customer: { title: 'Customers', icon: '🧑‍🤝‍🧑', pk: 'customer_id', list: ['customer_id','first_name','last_name','phone','email','address','aadhaar_no','pan_no'], fields: [
    f('first_name','First Name','text',true), f('last_name','Last Name'), f('phone','Phone','tel',true), f('email','Email','email'),
    f('address','Address'), f('aadhaar_no','Aadhaar No. (12 digits)'), f('pan_no','PAN No.')] },
  sales: { title: 'Sales', icon: '💰', pk: 'sale_id', list: ['sale_id','sale_date','customer_id','car_id','employee_id','discount','tax','total_amount','payment_status'], fields: [
    f('customer_id','Customer','fk',true,'customer'), f('employee_id','Sales Employee','fk',true,'employee'),
    f('car_id','Car','fk',true,'car'), f('sale_date','Sale Date','date',true),
    f('discount','Discount (₹)','number',false,null,0), f('tax','Tax (₹)','number',false,null,0),
    f('total_amount','Total (₹) = price − discount + tax','number',true),
    f('payment_status','Payment Status','select',false,['Pending','Paid'],'Pending')] },
  service: { title: 'Service', icon: '🔧', pk: 'jobcard_no', list: ['jobcard_no','service_date','customer_id','car_id','service_type','service_cost','next_service_date','status'], fields: [
    f('customer_id','Customer','fk',true,'customer'), f('car_id','Car','fk',true,'car'), f('service_date','Service Date','date',true),
    f('service_type','Service Type','select',false,['General Service','Oil Change','Engine Check','Brake Service','AC Service','Tyre Change','Other']),
    f('service_cost','Cost (₹)','number',false,null,0), f('next_service_date','Next Service Date','date'),
    f('status','Status','select',false,['Pending','In Progress','Completed'],'Pending')] },
  payment: { title: 'Payments', icon: '💳', pk: 'payment_id', list: ['payment_id','sale_id','payment_date','amount','payment_mode','transaction_no','status'], fields: [
    f('sale_id','Sale','fk',true,'sales'), f('payment_date','Payment Date','date',true), f('amount','Amount (₹)','number',true),
    f('payment_mode','Mode','select',false,['UPI','Card','Cash','Bank Transfer','Cheque']), f('transaction_no','Transaction No.'),
    f('status','Status','select',false,['Pending','Completed','Failed'],'Completed')] }
};
const MONEY = ['price','salary','discount','tax','total_amount','service_cost','amount'];
const LABEL = k => k.replace(/_id$/, '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

/* ---------- State + helpers ---------- */
const KEY = 'autohub_db_v1';
const $ = s => document.querySelector(s);
let DB = (() => { try { const d = JSON.parse(localStorage.getItem(KEY)); if (d) return d; } catch (e) {} return structuredClone(SEED); })();
const save = () => localStorage.setItem(KEY, JSON.stringify(DB));
const money = n => '₹' + Number(n || 0).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
const find = (t, id) => DB[t].find(r => r[T[t].pk] == id);
const nextId = t => Math.max(0, ...DB[t].map(r => r[T[t].pk])) + 1;
const fmtDate = d => d ? new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '';
const today = () => new Date().toISOString().slice(0, 10);
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400); }

function fkLabel(t, id) {
  const r = find(t, id); if (!r) return '—';
  switch (t) {
    case 'showroom': return r.showroom_name;
    case 'supplier': return r.supplier_name;
    case 'employee': return `${r.first_name} ${r.last_name || ''}`.trim();
    case 'customer': return `${r.first_name} ${r.last_name || ''}`.trim();
    case 'car': return `${r.brand} ${r.model} ${r.variant || ''} (#${r.car_id})`;
    case 'sales': return `Sale #${r.sale_id} – ${fkLabel('customer', r.customer_id)} – ${money(r.total_amount)}`;
  }
}
function badge(v) {
  const c = { Active:'g', Available:'g', Paid:'g', Completed:'g', Sold:'b', Pending:'a', 'In Progress':'a', Reserved:'a', Inactive:'r', Failed:'r' }[v] || '';
  return `<span class="badge ${c}">${esc(v)}</span>`;
}
function cell(t, k, r) {
  const fd = T[t].fields.find(x => x.k === k);
  const v = r[k];
  if (fd && fd.type === 'fk') return esc(fkLabel(fd.opts, v));
  if (MONEY.includes(k)) return money(v);
  if (/date$/.test(k)) return fmtDate(v);
  if (k === 'status' || k === 'payment_status') return badge(v);
  return esc(v);
}
const paidFor = id => DB.payment.filter(p => p.sale_id == id && p.status === 'Completed').reduce((s, p) => s + Number(p.amount), 0);

/* ---------- Navigation ---------- */
const NAV = [['dashboard','📊','Dashboard'], ['sep','Manage'], ...Object.keys(T).map(k => [k, T[k].icon, T[k].title]), ['sep','Insights'], ['reports','📑','Reports']];
$('#nav').innerHTML = NAV.map(n => n[0] === 'sep' ? `<div class="sep">${n[1]}</div>` : `<a href="#${n[0]}" data-r="${n[0]}"><span>${n[1]}</span>${n[2]}</a>`).join('');
$('#today').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
$('#menuBtn').onclick = () => $('#sidebar').classList.toggle('open');
$('#resetBtn').onclick = () => { if (confirm('Reset all data back to the original SQL sample data?')) { DB = structuredClone(SEED); save(); route(); toast('Demo data restored'); } };
window.addEventListener('hashchange', route);

let sortState = {}, searchState = {}, reportIdx = 0;
function route() {
  const r = location.hash.slice(1) || 'dashboard';
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('active', a.dataset.r === r));
  $('#sidebar').classList.remove('open');
  if (r === 'dashboard') { $('#pageTitle').textContent = 'Dashboard'; return dashboard(); }
  if (r === 'reports') { $('#pageTitle').textContent = 'Reports'; return reports(); }
  if (T[r]) { $('#pageTitle').textContent = T[r].title; return tableView(r); }
  location.hash = 'dashboard';
}

/* ---------- Dashboard ---------- */
function dashboard() {
  const totalRev = DB.sales.reduce((s, x) => s + Number(x.total_amount), 0);
  const outstanding = DB.sales.reduce((s, x) => s + Math.max(0, x.total_amount - paidFor(x.sale_id)), 0);
  const avail = DB.car.filter(c => c.status === 'Available').length;
  const pendSvc = DB.service.filter(s => s.status !== 'Completed').length;
  const byShow = DB.showroom.map(s => ({ name: s.showroom_name,
    val: DB.sales.filter(x => find('car', x.car_id)?.showroom_id == s.showroom_id).reduce((a, x) => a + Number(x.total_amount), 0) }));
  const max = Math.max(1, ...byShow.map(x => x.val));
  const recent = [...DB.sales].sort((a, b) => b.sale_date.localeCompare(a.sale_date)).slice(0, 5);
  const upcoming = [...DB.service].filter(s => s.next_service_date).sort((a, b) => a.next_service_date.localeCompare(b.next_service_date)).slice(0, 5);
  $('#view').innerHTML = `
  <div class="cards">
    <div class="stat"><small>Total Cars</small><b>${DB.car.length}</b></div>
    <div class="stat green"><small>Available in Stock</small><b>${avail}</b></div>
    <div class="stat"><small>Cars Sold</small><b>${DB.car.length - avail}</b></div>
    <div class="stat green"><small>Total Sales Revenue</small><b>${money(totalRev)}</b></div>
    <div class="stat red"><small>Outstanding Payments</small><b>${money(outstanding)}</b></div>
    <div class="stat amber"><small>Pending Services</small><b>${pendSvc}</b></div>
    <div class="stat"><small>Customers</small><b>${DB.customer.length}</b></div>
    <div class="stat"><small>Employees</small><b>${DB.employee.length}</b></div>
  </div>
  <div class="grid2">
    <div class="panel"><h3>Revenue by Showroom</h3>
      ${byShow.map(x => `<div class="bar-row"><span>${esc(x.name)}</span><div class="bar"><i style="width:${x.val / max * 100}%"></i></div><b>${money(x.val)}</b></div>`).join('')}
    </div>
    <div class="panel"><h3>Recent Sales</h3>
      ${tinyTable(['Date','Customer','Car','Total'], recent.map(s => [fmtDate(s.sale_date), fkLabel('customer', s.customer_id), fkLabel('car', s.car_id), money(s.total_amount)]))}
    </div>
  </div>
  <div class="grid2">
    <div class="panel"><h3>Upcoming Service Dates</h3>
      ${tinyTable(['Next Service','Customer','Car'], upcoming.map(s => [fmtDate(s.next_service_date), fkLabel('customer', s.customer_id), fkLabel('car', s.car_id)]))}
    </div>
    <div class="panel"><h3>Sales Payment Status</h3>
      ${tinyTable(['Sale','Total','Paid','Balance'], DB.sales.map(s => [`#${s.sale_id} ${fkLabel('customer', s.customer_id)}`, money(s.total_amount), money(paidFor(s.sale_id)), money(Math.max(0, s.total_amount - paidFor(s.sale_id)))]))}
    </div>
  </div>`;
}
function tinyTable(h, r) {
  if (!r.length) return '<div class="empty">No data</div>';
  return `<div style="overflow:auto"><table><thead><tr>${h.map(x => `<th class="noclick">${x}</th>`).join('')}</tr></thead><tbody>${r.map(x => `<tr>${x.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

/* ---------- Generic table view (CRUD) ---------- */
function tableView(t) {
  const S = T[t];
  $('#view').innerHTML = `
    <div class="toolbar">
      <input type="search" id="q" placeholder="Search ${S.title.toLowerCase()}…" value="${esc(searchState[t] || '')}">
      <button class="btn" id="csv">⬇ Export CSV</button>
      <button class="btn primary" id="add">＋ Add ${S.title.replace(/s$/, '')}</button>
    </div>
    <div class="count" id="count"></div>
    <div class="tablewrap"><table>
      <thead><tr>${S.list.map(k => `<th data-k="${k}">${LABEL(k)} <span id="s_${k}"></span></th>`).join('')}<th class="noclick"></th></tr></thead>
      <tbody id="tbody"></tbody></table></div>`;
  const draw = () => {
    const q = (searchState[t] || '').toLowerCase();
    let data = DB[t].filter(r => !q || Object.keys(r).some(k => {
      const fd = S.fields.find(x => x.k === k);
      return String(fd?.type === 'fk' ? fkLabel(fd.opts, r[k]) : r[k]).toLowerCase().includes(q); }));
    const st = sortState[t];
    if (st) data.sort((a, b) => { const x = a[st.k], y = b[st.k]; const c = typeof x === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? '')); return st.dir * c; });
    S.list.forEach(k => $('#s_' + k).textContent = st && st.k === k ? (st.dir > 0 ? '▲' : '▼') : '');
    $('#count').textContent = `${data.length} record${data.length !== 1 ? 's' : ''}`;
    $('#tbody').innerHTML = data.length ? data.map(r => `<tr>${S.list.map(k => `<td class="${MONEY.includes(k) ? 'num' : ''}">${cell(t, k, r)}</td>`).join('')}
      <td class="act"><button class="btn small" data-e="${r[S.pk]}">Edit</button> <button class="btn small danger" data-d="${r[S.pk]}">Delete</button></td></tr>`).join('')
      : `<tr><td colspan="${S.list.length + 1}" class="empty">No records found</td></tr>`;
  };
  draw();
  $('#q').oninput = e => { searchState[t] = e.target.value; draw(); };
  document.querySelectorAll('th[data-k]').forEach(th => th.onclick = () => { const k = th.dataset.k; const s = sortState[t]; sortState[t] = { k, dir: s && s.k === k ? -s.dir : 1 }; draw(); });
  $('#add').onclick = () => openForm(t);
  $('#csv').onclick = () => exportCSV(t + '.csv', DB[t]);
  $('#tbody').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.e) openForm(t, b.dataset.e);
    if (b.dataset.d) removeRec(t, b.dataset.d, draw);
  };
}

function removeRec(t, id, redraw) {
  const refs = [];
  for (const [tn, sc] of Object.entries(T)) for (const fd of sc.fields)
    if (fd.type === 'fk' && fd.opts === t) { const n = DB[tn].filter(r => r[fd.k] == id).length; if (n) refs.push(`${n} in ${sc.title}`); }
  if (refs.length) return alert(`Cannot delete: this record is used by ${refs.join(', ')}.\nRemove those first.`);
  if (!confirm('Delete this record permanently?')) return;
  DB[t] = DB[t].filter(r => r[T[t].pk] != id);
  save(); redraw(); toast('Record deleted');
}

/* ---------- Add / Edit form ---------- */
let editing = null;
function openForm(t, id = null) {
  const S = T[t]; const rec = id ? find(t, id) : null; editing = { t, id };
  $('#modalTitle').textContent = `${rec ? 'Edit' : 'Add'} ${S.title.replace(/s$/, '')}`;
  $('#formError').textContent = '';
  const idVal = rec ? rec[S.pk] : nextId(t);
  let html = `<div class="field"><label>${LABEL(S.pk)}</label><input value="${idVal}" disabled></div>`;
  for (const fd of S.fields) {
    const v = rec ? rec[fd.k] : (t === 'sales' && fd.k === 'sale_date') || (t === 'service' && fd.k === 'service_date') || (t === 'payment' && fd.k === 'payment_date') ? today() : fd.def;
    const req = fd.req ? '<em>*</em>' : '';
    let inp;
    if (fd.type === 'select') inp = `<select name="${fd.k}">${(fd.opts.includes(v) || !v ? fd.opts : [v, ...fd.opts]).map(o => `<option ${o == v ? 'selected' : ''}>${o}</option>`).join('')}</select>`;
    else if (fd.type === 'fk') {
      let list = DB[fd.opts];
      if (t === 'sales' && fd.k === 'car_id') list = list.filter(c => c.status === 'Available' || (rec && c.car_id == rec.car_id)); // only unsold cars
      inp = `<select name="${fd.k}"><option value="">— select —</option>${list.map(o => `<option value="${o[T[fd.opts].pk]}" ${o[T[fd.opts].pk] == v ? 'selected' : ''}>${esc(fkLabel(fd.opts, o[T[fd.opts].pk]))}</option>`).join('')}</select>`;
    } else inp = `<input name="${fd.k}" type="${fd.type}" value="${esc(v)}" ${fd.type === 'number' ? 'step="any" min="0"' : ''} ${fd.k === 'aadhaar_no' ? 'maxlength="12"' : ''} ${fd.k === 'pan_no' ? 'maxlength="10"' : ''}>`;
    html += `<div class="field"><label>${fd.label} ${req}</label>${inp}</div>`;
  }
  $('#formFields').innerHTML = html;
  $('#modal').showModal();
}
// Auto-calc sale total when car / discount / tax change
$('#form').addEventListener('input', () => {
  if (!editing || editing.t !== 'sales') return;
  const g = n => $(`#form [name=${n}]`);
  const car = find('car', g('car_id').value);
  if (car) g('total_amount').value = Number(car.price) - Number(g('discount').value || 0) + Number(g('tax').value || 0);
});
const closeForm = () => $('#modal').close();
$('#closeModal').onclick = $('#cancelBtn').onclick = closeForm;

$('#form').addEventListener('submit', e => {
  e.preventDefault();
  const { t, id } = editing, S = T[t], err = m => { $('#formError').textContent = m; };
  const rec = {};
  for (const fd of S.fields) {
    let v = $(`#form [name=${fd.k}]`).value.trim();
    if (fd.req && !v) return err(`${fd.label.split('(')[0].trim()} is required.`);
    if (fd.type === 'number') v = v === '' ? 0 : Number(v);
    else if (fd.type === 'fk') v = v === '' ? null : Number(v);
    rec[fd.k] = v;
  }
  // validations
  if (rec.email && !/^\S+@\S+\.\S+$/.test(rec.email)) return err('Enter a valid email address.');
  if (rec.phone && !/^\d{10,15}$/.test(rec.phone)) return err('Phone must be 10–15 digits.');
  if (t === 'customer') {
    if (rec.aadhaar_no && !/^\d{12}$/.test(rec.aadhaar_no)) return err('Aadhaar must be exactly 12 digits.');
    if (rec.pan_no && !/^[A-Z]{5}\d{4}[A-Z]$/i.test(rec.pan_no)) return err('PAN format should be like ABCDE1234F.');
    rec.pan_no = rec.pan_no.toUpperCase();
    for (const k of ['aadhaar_no', 'pan_no']) // UNIQUE constraints
      if (rec[k] && DB.customer.some(c => c[k] === rec[k] && c.customer_id != id)) return err(`${LABEL(k)} already exists for another customer.`);
    rec.aadhaar_no ||= null; rec.pan_no ||= null;
  }
  if (t === 'sales' && DB.sales.some(s => s.car_id == rec.car_id && s.sale_id != id)) return err('This car has already been sold (UNIQUE car_id).');
  if (t === 'payment') { const s = find('sales', rec.sale_id); if (rec.amount <= 0) return err('Amount must be greater than 0.'); }

  if (t === 'service' && !id) rec.status = 'Pending'; // mirrors BEFORE INSERT trigger set_service_status
  const isNew = !id;
  if (isNew) { rec[S.pk] = nextId(t); DB[t].push(rec); }
  else { rec[S.pk] = Number(id); Object.assign(find(t, id), rec); }

  // mirrors AFTER INSERT trigger trg_mark_car_sold
  if (t === 'sales') {
    DB.car.forEach(c => { if (c.car_id == rec.car_id) c.status = 'Sold'; });
    if (!isNew) { /* free a car that was swapped out */ DB.car.forEach(c => { if (c.status === 'Sold' && !DB.sales.some(s => s.car_id == c.car_id) && c.car_id != rec.car_id && c.status === 'Sold' && false) c.status = 'Available'; }); }
  }
  // auto-settle sale when payments cover the total
  if (t === 'payment') {
    const s = find('sales', rec.sale_id);
    if (s) s.payment_status = paidFor(s.sale_id) >= s.total_amount ? 'Paid' : 'Pending';
  }
  save(); closeForm(); route();
  toast(isNew ? 'Record added' : 'Record updated');
});

/* ---------- Reports (the SQL queries from the project) ---------- */
const REPORTS = [
  { name: 'Sold cars', sql: "SELECT * FROM CAR WHERE status='Sold' ORDER BY car_id", run: () => DB.car.filter(c => c.status === 'Sold').sort((a, b) => a.car_id - b.car_id).map(c => ({ ID: c.car_id, Brand: c.brand, Model: c.model, Variant: c.variant, Fuel: c.fuel_type, Price: money(c.price) })) },
  { name: 'Available cars', sql: "SELECT * FROM CAR WHERE status='Available' ORDER BY price", run: () => DB.car.filter(c => c.status === 'Available').sort((a, b) => a.price - b.price).map(c => ({ ID: c.car_id, Brand: c.brand, Model: c.model, Variant: c.variant, Fuel: c.fuel_type, Price: money(c.price), Showroom: fkLabel('showroom', c.showroom_id) })) },
  { name: 'Employees & showrooms', sql: 'EMPLOYEE JOIN SHOWROOM ORDER BY showroom_name', run: () => DB.employee.map(e => ({ Name: fkLabel('employee', e.employee_id), Designation: e.designation, Showroom: fkLabel('showroom', e.showroom_id) })).sort((a, b) => a.Showroom.localeCompare(b.Showroom)) },
  { name: 'Customer purchases', sql: 'CUSTOMER JOIN SALES JOIN CAR ORDER BY total_amount DESC', run: () => DB.sales.map(s => { const c = find('car', s.car_id); return { Customer: fkLabel('customer', s.customer_id), Brand: c?.brand, Model: c?.model, Total: s.total_amount }; }).sort((a, b) => b.Total - a.Total).map(r => ({ ...r, Total: money(r.Total) })) },
  { name: 'Revenue by payment status', sql: 'SELECT payment_status, SUM(total_amount) FROM SALES GROUP BY payment_status', run: () => { const m = {}; DB.sales.forEach(s => m[s.payment_status] = (m[s.payment_status] || 0) + Number(s.total_amount)); return Object.entries(m).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ 'Payment Status': k, 'Total Revenue': money(v) })); } },
  { name: 'Cars by price', sql: 'SELECT brand, model, price FROM CAR ORDER BY price DESC', run: () => [...DB.car].sort((a, b) => b.price - a.price).map(c => ({ Brand: c.brand, Model: c.model, Price: money(c.price) })) },
  { name: 'Employees per showroom', sql: 'SHOWROOM LEFT JOIN EMPLOYEE GROUP BY showroom ORDER BY COUNT DESC', run: () => DB.showroom.map(s => ({ Showroom: s.showroom_name, 'Total Employees': DB.employee.filter(e => e.showroom_id == s.showroom_id).length })).sort((a, b) => b['Total Employees'] - a['Total Employees'] || a.Showroom.localeCompare(b.Showroom)) },
  { name: 'Pending sales', sql: "SELECT * FROM SALES WHERE payment_status='Pending' ORDER BY sale_date", run: () => DB.sales.filter(s => s.payment_status === 'Pending').sort((a, b) => a.sale_date.localeCompare(b.sale_date)).map(s => ({ Sale: s.sale_id, Customer: fkLabel('customer', s.customer_id), Date: fmtDate(s.sale_date), Total: money(s.total_amount), Paid: money(paidFor(s.sale_id)), Balance: money(s.total_amount - paidFor(s.sale_id)) })) },
  { name: 'Service history', sql: 'SERVICE JOIN CUSTOMER JOIN CAR ORDER BY service_date DESC', run: () => [...DB.service].sort((a, b) => b.service_date.localeCompare(a.service_date)).map(s => ({ Customer: fkLabel('customer', s.customer_id), Car: fkLabel('car', s.car_id), Service: s.service_type, Cost: money(s.service_cost), Status: s.status, Date: fmtDate(s.service_date) })) },
  { name: 'Completed payments', sql: "SELECT * FROM PAYMENT WHERE status='Completed' ORDER BY payment_id DESC", run: () => DB.payment.filter(p => p.status === 'Completed').sort((a, b) => b.payment_id - a.payment_id).map(p => ({ Payment: p.payment_id, Sale: p.sale_id, Amount: money(p.amount), Mode: p.payment_mode, Status: p.status })) },
  { name: 'Suppliers & cars', sql: 'SUPPLIER JOIN CAR ORDER BY supplier_name', run: () => DB.car.map(c => { const s = find('supplier', c.supplier_id); return { Supplier: s?.supplier_name, Contact: s?.contact_person, Brand: c.brand, Model: c.model, Price: money(c.price) }; }).sort((a, b) => a.Supplier.localeCompare(b.Supplier)) }
];
function reports() {
  const R = REPORTS[reportIdx], data = R.run();
  $('#view').innerHTML = `
    <div class="tabs">${REPORTS.map((r, i) => `<button class="${i === reportIdx ? 'on' : ''}" data-i="${i}">${r.name}</button>`).join('')}</div>
    <div class="sql">${esc(R.sql)}</div>
    <div class="toolbar"><span class="count" style="flex:1;margin:0">${data.length} row${data.length !== 1 ? 's' : ''}</span><button class="btn" id="rcsv">⬇ Export CSV</button></div>
    <div class="tablewrap">${data.length ? `<table><thead><tr>${Object.keys(data[0]).map(k => `<th class="noclick">${k}</th>`).join('')}</tr></thead><tbody>${data.map(r => `<tr>${Object.values(r).map(v => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '<div class="empty">No results</div>'}</div>`;
  document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { reportIdx = +b.dataset.i; reports(); });
  $('#rcsv').onclick = () => exportCSV(R.name.replace(/\W+/g, '_') + '.csv', data);
}

function exportCSV(name, data) {
  if (!data.length) return toast('Nothing to export');
  const keys = Object.keys(data[0]);
  const csv = [keys.join(','), ...data.map(r => keys.map(k => `"${String(r[k] ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = name; a.click();
}

route();
